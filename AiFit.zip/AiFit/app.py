from flask import Flask, render_template, Response, jsonify
import cv2
from squat_tracker import SquatTracker
from triceps_tracker import TricepsTracker  # новый импорт

app = Flask(__name__)

squat_tracker = SquatTracker()
triceps_tracker = TricepsTracker()  # новый трекер

# ---- Приседания ----
def generate_squat_frames():
    cap = cv2.VideoCapture(0)
    while True:
        success, frame = cap.read()
        if not success:
            break
        processed_frame = squat_tracker.process_frame(frame)
        ret, buffer = cv2.imencode('.jpg', processed_frame)
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
    cap.release()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/squat')
def squat():
    return render_template('squat.html')

@app.route('/squat_video_feed')
def squat_video_feed():
    return Response(generate_squat_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/squat_stats')
def squat_stats():
    return jsonify(squat_tracker.get_stats())

@app.route('/squat_reset')
def squat_reset():
    squat_tracker.reset()
    return jsonify(squat_tracker.get_stats())

# ---- Трицепс ----
def generate_triceps_frames():
    cap = cv2.VideoCapture(0)
    while True:
        success, frame = cap.read()
        if not success:
            break
        processed_frame = triceps_tracker.process_frame(frame)
        ret, buffer = cv2.imencode('.jpg', processed_frame)
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
    cap.release()

@app.route('/triceps')
def triceps():
    return render_template('triceps.html')

@app.route('/triceps_video_feed')
def triceps_video_feed():
    return Response(generate_triceps_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/triceps_stats')
def triceps_stats():
    return jsonify(triceps_tracker.get_stats())

@app.route('/triceps_reset')
def triceps_reset():
    triceps_tracker.reset()
    return jsonify(triceps_tracker.get_stats())

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)