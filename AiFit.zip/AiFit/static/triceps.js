// Обновление статистики для трицепса
function updateStats() {
    fetch('/triceps_stats')
        .then(response => response.json())
        .then(data => {
            document.getElementById('reps-count').textContent = data.reps;
            
            const formElement = document.getElementById('form-status');
            const formBadge = document.getElementById('form-badge');
            
            let formColor = '';
            
            if (data.form === "Отлично! ✨") {
                formColor = 'linear-gradient(135deg, #00b894, #00cec9)';
            } else if (data.form === "Плохо 📏") {
                formColor = 'linear-gradient(135deg, #d63031, #e17055)';
            } else {
                formColor = 'linear-gradient(135deg, #b2bec3, #636e72)';
            }
            
            formElement.textContent = data.form;
            formBadge.style.background = formColor;
            
            formBadge.style.transform = 'scale(1.05)';
            setTimeout(() => formBadge.style.transform = 'scale(1)', 200);

            updateCameraStatus(true);
        })
        .catch(error => {
            console.error('Error:', error);
            updateCameraStatus(false);
        });
}

function updateCameraStatus(isActive) {
    const statusBadge = document.getElementById('camera-status');
    const statusDot = document.getElementById('status-dot');
    const statusText = document.getElementById('status-text');
    
    if (isActive) {
        statusBadge.style.background = 'rgba(0, 0, 0, 0.3)';
        statusDot.style.background = '#4CAF50';
        statusDot.style.animation = 'blink 2s infinite';
        statusText.textContent = 'Камера активна';
    } else {
        statusBadge.style.background = 'rgba(255, 0, 0, 0.3)';
        statusDot.style.background = '#ff4444';
        statusDot.style.animation = 'none';
        statusText.textContent = 'Камера не доступна';
        document.getElementById('form-status').textContent = 'Нет сигнала';
    }
}

function resetCounter() {
    fetch('/triceps_reset')
        .then(response => response.json())
        .then(data => {
            document.getElementById('reps-count').textContent = data.reps;
            document.getElementById('form-status').textContent = 'Ожидание';
            showNotification('Счетчик сброшен! 🔄');
            
            const counter = document.querySelector('.reps-badge .stats-value');
            counter.style.transform = 'scale(1.5)';
            counter.style.transition = 'transform 0.3s';
            setTimeout(() => counter.style.transform = 'scale(1)', 300);
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('Ошибка при сбросе', 'error');
        });
}

function showNotification(message, type = 'success') {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.className = 'notification show';
    notification.style.background = type === 'error' 
        ? 'linear-gradient(135deg, #ff6b6b, #ee5253)' 
        : 'linear-gradient(135deg, #4158D0, #C850C0)';
    setTimeout(() => notification.classList.remove('show'), 3000);
}

document.addEventListener('DOMContentLoaded', function() {
    updateStats();
});

setInterval(updateStats, 500);