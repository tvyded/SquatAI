import cv2
import mediapipe as mp
import numpy as np


class TricepsTracker:
    def __init__(self):
        self.mp_pose = mp.solutions.pose
        self.pose = self.mp_pose.Pose(
            static_image_mode=False,
            model_complexity=1,
            enable_segmentation=False,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )
        self.draw = mp.solutions.drawing_utils
        self.reps = 0
        self.stage = "UP"
        self.good_flag = False
        self.bad_flag = False
        self.last_result = ""

    def calculate_angle(self, a, b, c):
        a, b, c = np.array(a), np.array(b), np.array(c)
        rad = np.arctan2(c[1] - b[1], c[0] - b[0]) - np.arctan2(a[1] - b[1], a[0] - b[0])
        ang = abs(rad * 180 / np.pi)
        return 360 - ang if ang > 180 else ang

    def process_frame(self, frame):
        frame = cv2.flip(frame, 1)
        img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        res = self.pose.process(img)
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

        if res.pose_landmarks:
            lm = res.pose_landmarks.landmark

            # Точки для правой руки
            shoulder = [lm[12].x, lm[12].y]
            elbow = [lm[14].x, lm[14].y]
            wrist = [lm[16].x, lm[16].y]

            # Угол в локте
            arm_angle = self.calculate_angle(shoulder, elbow, wrist)

            # Определяем фазы по углу
            if arm_angle > 150:  # Рука прямая - фаза поднимания
                if self.stage == "DOWN":  # Только что закончили опускание
                    if self.good_flag and not self.bad_flag:
                        self.reps += 1
                        self.last_result = "GOOD REP!"
                    else:
                        self.last_result = "BAD REP!"
                self.stage = "UP"
                self.good_flag = False
                self.bad_flag = False

            elif arm_angle < 100:  # Рука согнута - фаза опускания
                self.stage = "DOWN"
                # Проверяем углы во время опускания
                if 80 <= arm_angle <= 100:
                    self.good_flag = True
                elif arm_angle < 70 or arm_angle > 150:
                    self.bad_flag = True

            # Рисуем скелет
            self.draw.draw_landmarks(img, res.pose_landmarks, self.mp_pose.POSE_CONNECTIONS)

        return img

    def get_stats(self):
        form_text = "Ожидание"
        if self.last_result == "GOOD REP!":
            form_text = "Отлично! ✨"
        elif self.last_result == "BAD REP!":
            form_text = "Плохо 📏"

        return {
            'reps': self.reps,
            'form': form_text,
            'stage': self.stage,
            'good_flag': self.good_flag,
            'bad_flag': self.bad_flag
        }

    def reset(self):
        self.reps = 0
        self.stage = "UP"
        self.good_flag = False
        self.bad_flag = False
        self.last_result = ""